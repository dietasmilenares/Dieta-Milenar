# Relatório Técnico — SaaS Dieta Milenar
**Auditoria DevOps — Versão 1.0**

---

## 1. Stack Identificada

| Camada | Tecnologia | Versão |
|--------|-----------|--------|
| Runtime | Node.js | ≥ 18 (recomendado 20 LTS) |
| Linguagem | TypeScript | ~5.8.2 |
| Backend framework | Express | ^5.2.1 |
| Frontend framework | React | ^19.2.3 |
| Bundler | Vite | ^6.2.0 |
| Banco de dados | MySQL | 5.7+ / 8.0 |
| Autenticação | JWT (jsonwebtoken) | ^9.0.2 |
| Upload de arquivos | Multer | ^1.4.5 |
| Pagamentos | Stripe | ^20.4.0 |
| Estilização | Tailwind CSS | ^4.2.1 |
| Processo em produção | PM2 | latest |
| Proxy reverso | Nginx | latest |

---

## 2. Arquitetura do Sistema

```
[Usuário]
   │
   ▼
[Nginx :80/:443]  ← proxy reverso + SSL
   │
   ▼
[Node/Express :3000]  ← server.ts (API REST + serve static)
   │
   ├── /api/*          → Rotas REST (auth, users, orders, etc.)
   ├── /e-books/*      → Arquivos HTML dos e-books (public/ ou dist/)
   ├── /proofs/*       → Comprovantes de pagamento (upload dinâmico)
   └── /*              → SPA React (dist/index.html)
   │
   ▼
[MySQL :3306]  ← banco de dados principal
```

---

## 3. Dependências Obrigatórias

### Sistema operacional
- Ubuntu 20.04+ / Debian 11+
- Node.js 20 LTS
- MySQL 5.7+ ou 8.0
- Nginx
- PM2 (npm global)

### Pacotes npm (produção)
| Pacote | Função |
|--------|--------|
| express | Servidor HTTP / API REST |
| mysql2 | Driver MySQL com pool de conexões |
| jsonwebtoken | Autenticação JWT |
| multer | Upload de arquivos (e-books, comprovantes) |
| stripe | Gateway de pagamento |
| bcryptjs | Hash de senhas |
| dotenv | Variáveis de ambiente |
| tsx | Executa TypeScript diretamente (sem compilar) |
| vite + react | Build do frontend SPA |
| tailwindcss | CSS utilitário |

### Serviços externos (configurar no .env)
| Serviço | Obrigatório | Variável |
|---------|-------------|----------|
| MySQL | ✅ Sim | DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME |
| JWT Secret | ✅ Sim | JWT_SECRET |
| Stripe | ⚠️ Parcial | STRIPE_SECRET_KEY (só para pagamentos com cartão) |

> **Firebase:** O projeto migrou Firebase para MySQL + JWT. O arquivo `src/firebase.ts` é um stub vazio mantido apenas para não quebrar imports. **Não instalar Firebase.**

---

## 4. Estrutura de Tabelas do Banco

```
users
  └── user_profiles
  └── orders
        └── commissions
  └── withdrawals
  └── notifications
  └── reseller_requests

plans
categories
  └── subcategories
        └── ebooks

bonus_categories
  └── bonus_items

bonuses
products
  └── product_modules
        └── product_chapters

bots
  └── timelines
        └── timeline_blocks

affiliate_clicks
global_settings
```

---

## 5. Fluxo de Execução

### Desenvolvimento
```bash
npm install
cp .env.example .env  # Editar com suas credenciais
npm run dev           # Inicia server.ts com Vite em modo middleware
```

### Produção
```bash
npm install --omit=dev
npm run build         # Gera dist/ com o frontend compilado
NODE_ENV=production tsx server.ts
# ou via PM2:
pm2 start ecosystem.config.cjs --env production
```

---

## 6. Variáveis de Ambiente Necessárias

```env
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=dieta_user
DB_PASS=senha_forte_aqui
DB_NAME=dieta_milenar

JWT_SECRET=chave_aleatoria_32_chars_minimo

STRIPE_SECRET_KEY=sk_live_...   # ou sk_test_ para testes

PORT=3000
NODE_ENV=production
```

---

## 7. Diretórios Importantes em Produção

| Diretório | Conteúdo |
|-----------|---------|
| `dist/` | Frontend compilado pelo Vite |
| `public/e-books/` | E-books em HTML (upload via painel) |
| `public/proofs/` | Comprovantes de pagamento enviados |
| `public/img/` | Imagens do sistema |
| `socialmembers/` | Listas de nomes/sobrenomes para o chat social |

---

## 8. Roles de Usuário

| Role | Acesso |
|------|--------|
| VISITANTE | Acesso básico, sem conteúdo pago |
| MEMBRO | Acesso ao conteúdo após pagamento confirmado |
| REVENDA | Afiliado com link de indicação e comissões |
| ADMIN | Acesso total ao painel administrativo |

---

## 9. Login Padrão

| Campo | Valor |
|-------|-------|
| E-mail | admin@dietasmilenares.com |
| Senha | admin123 |

> ⚠️ **Trocar imediatamente após o primeiro acesso.**

---

## 10. Itens que NÃO são necessários instalar

- ❌ Firebase / Firestore (migrado para MySQL)
- ❌ Redis (não utilizado)
- ❌ Docker (não obrigatório)
- ❌ PHP / Apache (não usado)
- ❌ Python / pip (não usado)
- ❌ Qualquer serviço de fila (sem workers assíncronos)

---

## 11. Observações de Segurança

1. **Senhas em texto puro:** O sistema atualmente armazena `password_hash` sem hash real (compara diretamente). Recomenda-se ativar o `bcryptjs` já presente no projeto.
2. **JWT Secret:** Gerar com `openssl rand -hex 32` e nunca commitar no repositório.
3. **Stripe Key:** Usar chave `sk_live_` apenas em produção, nunca expor no frontend.
4. **.env:** Nunca versionar. Permissão recomendada: `chmod 600 .env`.
5. **MySQL:** Criar usuário dedicado com acesso apenas ao banco da aplicação, nunca usar `root`.
